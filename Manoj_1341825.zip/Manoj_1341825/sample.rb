def check_one i
$count=0
	
	(0...3).each { |j|
  		if $arr[i][j] == 1
  			$count +=1;
  		end
	}
	
	if $count == 3
		puts " horizontal match"
 		return false
	end 
	
	$count=0
	(0...3).each { |j|
  		if $arr[j][i] == 1
  			$count +=1;
  		end
	}
	if $count == 3
		puts " vertical match"
 		return false
	end 
	
	$count=0
	(0...3).each { |j|
  		if $arr[j][j] == 1
  			$count +=1;
  		end
		
	}
	if $count == 3
		puts " diagnol match"
 		return false
	end

	return true

end

def check_zero i
$count=0
	
	(0...3).each { |j|
  		if $arr[i][j] == 0
  			$count +=1;
  		end
	}
	
	if $count == 3
		puts " horizontal match"
 		return false
	end 
	
	$count=0
	(0...3).each { |j|
  		if $arr[j][i] == 0
  			$count +=1;
  		end
	}
	if $count == 3
		puts " vertical match"
 		return false
	end 
	
	$count=0
	(0...3).each { |j|
  		if $arr[j][j] == 0
  			$count +=1;
  		end
	}
	if $count == 3
		puts " diagnol match"
 		return false
	end

	return true

end




$arr =[[nil,nil,nil],[nil,nil,nil],[nil,nil,nil]]

puts " The given input is : "

(0...3).each { |i|
	(0...3).each{ |j|
	  puts "Enter i,j and value: \t"
	  print "i: \t"
	  a=gets.to_i
	  print "j: \t"
	  b=gets.to_i
	  print "value: \t"
	  c=gets.to_i
	  
	 $arr[a][b]=c
	 var1=check_one a
	 var2=check_zero a
	 if( var1 == false)
	 	puts " user 1 won the game"
		exit
	 elsif(var2 == false)
	 	puts " user 0 won the game"
		exit
	 end
	 
	 var1=check_one b
	 var2=check_zero b
	 if( var1 == false)
	 	puts " user 1 won the game"
		exit
	 elsif(var2 == false)
	 	puts " user 0 won the game"
		exit
	 end
	}
 puts " "
}
if var1==true && var2==true
puts " game got tied"
end

